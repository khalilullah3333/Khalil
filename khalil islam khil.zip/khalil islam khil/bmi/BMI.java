package bmi;

import java.util.Scanner;

public class BMI {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("please Enter weight in Kg");
        double weight = input.nextDouble();
        System.out.println("please Enter height in M");
        double height = input.nextDouble();
        double result = weight / height * height;
        if (result >= 30.0) {
            System.out.println("you are obses");
        } else if (result >= 25.0) {
            System.out.println("you are over weight");
        } else if (result >= 18.5) {
            System.out.println("yor are normal");
        } else if (result < 18.5) {
            System.out.println("yor are under weight");
        }
    }

}
