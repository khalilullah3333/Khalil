
package declareavariable;


public class DeclareaVariable {

   
    public static void main(String[] args) {
int x=5;
System.out.println(x);
    }
    
}
