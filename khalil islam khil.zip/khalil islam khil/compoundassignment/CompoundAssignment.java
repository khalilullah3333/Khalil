
package compoundassignment;

public class CompoundAssignment {


    public static void main(String[] args) {
       int x=5;
       x+=4;
       System.out.println(x);
       x-=4;
        System.out.println(x);
        x*=4;
        System.out.println(x);
        x/=4;
        System.out.println(x);
        x%=4;
        System.out.println(x);
    }
    
}
