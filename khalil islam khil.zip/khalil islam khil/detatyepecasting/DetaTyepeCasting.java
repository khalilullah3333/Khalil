
package detatyepecasting;

public class DetaTyepeCasting {

    
    public static void main(String[] args) {
        double a=9.7;
       int b=(int)a;
       System.out.println(b);
    }
    
}
