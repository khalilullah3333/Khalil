

package areaofacircleusingaconstant;

import java.util.Scanner;

public class AreaofaCircleUsingaConstant {

    
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        double area,R;
         final double Pi=3.14;
       
          System.out.println("Enter valuo for R");
    R=input.nextDouble();  
    area=Pi*R*R;
    System.out.println(area);
    }
    
}
