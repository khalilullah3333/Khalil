
package declareandinitialize;

public class DeclareandInitialize {


    public static void main(String[] args) {
        char x='A';
        int y=100;
        System.out.println(x);
         System.out.println(y);
       
    }
    
}
