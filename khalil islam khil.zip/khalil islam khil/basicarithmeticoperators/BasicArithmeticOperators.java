
package basicarithmeticoperators;

public class BasicArithmeticOperators {

    
    public static void main(String[] args) {
      double a=10;
       double b=20;
      
        System.out.println(a+b);
         System.out.println(a-b);
          System.out.println(a*b);
           System.out.println(a/b);
    }
    
}
