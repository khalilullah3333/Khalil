
package imb;

import java.util.Scanner;


public class IMB {
    public static void main(String[] args) {
       Scanner input=new Scanner(System.in);
      System.out.println("pleas Einter your weight to (Kg)");
      double weitht=input.nextDouble();
      System.out.println("pleas enter your height to(M)");
      double height=input.nextDouble();
      
      double BMI=weitht/(height*height);
      if(BMI<18.5)
          System.out.println("underweight");
      else if(BMI<24.9)
          System.out.println("normal");
      else if(BMI<29.9)
          System.out.println("overweight");
      else  if(BMI>30)
              System.out.println("obesity");
      
      
          }

    private static double height(KeyCode keyCode) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
